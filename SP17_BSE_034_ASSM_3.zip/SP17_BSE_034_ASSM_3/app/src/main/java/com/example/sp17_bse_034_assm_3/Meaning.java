package com.example.sp17_bse_034_assm_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Meaning extends AppCompatActivity {
    TextView meaningText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meanings);

        Intent data = new Intent();
        int pos = data.getIntExtra("position" , 0);
        String [] word = getResources().getStringArray(R.array.words);
        String [] meaning = getResources().getStringArray(R.array.meanings);
        meaningText = findViewById(R.id.meaningText);
        meaningText.setText("The meaning of the word:"+word[pos]+"is\n"+meaning[pos]);

    }
}
