package com.example.sp17_bse_034_assm_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    RecyclerView recycleview;
    String words[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycleview = findViewById(R.id.recycleView);
        recycleview.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recycleview.setLayoutManager(layoutManager);



        words = getResources().getStringArray(R.array.words);
        Adap dictionaryAdapter = new Adap(words);

        recycleview.setAdapter(dictionaryAdapter);



    }
}
