package com.example.sp17_bse_034_assm_3;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Adap extends  RecyclerView.Adapter<Adap.ViewHolder>{

    String wordData[];
    public Adap(String [] word)
    {
        wordData = word;
    }

    @NonNull
    @Override
    public Adap.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView textView = (TextView)
                LayoutInflater.from(parent.getContext()).inflate(R.layout.word_list , parent , false);
        ViewHolder viewHolder = new ViewHolder(textView);
        return  viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adap.ViewHolder holder, int position) {
    holder.textView.setText(wordData[position]);
    }

    @Override
    public int getItemCount() {
        return wordData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView;
        public ViewHolder(@NonNull TextView itemView) {
            super(itemView);
            textView =  itemView;
            textView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            intent.setClass(v.getContext() , Meaning.class);
            intent.putExtra("position" , getAdapterPosition());
            v.getContext().startActivity(intent);

        }
    }
}
